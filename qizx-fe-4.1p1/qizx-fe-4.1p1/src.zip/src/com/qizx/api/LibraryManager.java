/*
 *    Qizx Free_Engine-4.1p1
 *
 *    This code is part of Qizx XQuery engine
 *    Copyright (c) 2004-2010 Axyana Software -- All rights reserved.
 *
 *    For conditions of use, see the accompanying license files.
 */
package com.qizx.api;

import com.qizx.api.fulltext.FullTextFactory;
import com.qizx.api.util.DefaultModuleResolver;
import com.qizx.api.util.logging.Log;
import com.qizx.xdm.DocumentPool;

import java.io.File;
import java.util.logging.Handler;
import java.util.logging.Logger;

/**
 * Manages a group of XML Libraries.
 * <p>
 * A LibraryManager manages a bundle of XML Libraries and federates resources like
 * memory caches. It can be seen as the core of a server.
 * <p>
 * User sessions ({@link Library}) are obtained from a LibraryManager, by calling
 * the {@link #openLibrary(String)} methods.
 * <p>
 * A LibraryManager instance can be obtained through a {@link LibraryManagerFactory}:
 * <ul>
 * <li>by creating it empty ({@link LibraryManagerFactory#createManager}).
 * <li>by opening a Library Group ({@link LibraryManagerFactory#openLibraryGroup}).
 * <li>by creating a Library Group ({@link LibraryManagerFactory#createLibraryGroup}).
 * </ul>
 * <p>
 * A Library Group is merely a directory that contains a sub-directory for each
 * XML Library belonging to the group. Note that there is no delete method for
 * a group: to delete it, simply delete its storage directory.
 */
public interface LibraryManager
{
    /**
     * Returns the names of XML Libraries managed by this object.
     * @return a sorted array of Library names
     * @throws DataModelException if there is a system access problem.
     */
    String[] listLibraries()
        throws DataModelException;

    /**
     * Creates a new XML Library and manages it in this LibraryManager.
     * @param libraryName symbolic name of a Library.
     * @param libraryDirectory the location of the new Library. It represents a
     *        directory. If the directory exists, it must be empty. If value is
     *        null, the Library will be created as a sub-directory of the 'group
     *        directory' of this LibraryManager, which must be defined (see
     *        {@link #setGroupDirectory}. The sub-directory will have the name
     *        of the Library (parameter libraryName).
     * @exception DataModelException if specified library already exists, if
     *            specified library name already used.
     * @since 4.0 This method has been changed in 4.0, it has different parameters
     *        and no more opens a session.
     */
    void createLibrary(String libraryName, File libraryDirectory)
        throws LibraryException;

    /**
     * Physically destroys a Library.
     * @param libraryName symbolic name of the Library to destroy
     * @return <code>true</code> if specified library has been deleted;
     *         <code>false</code> otherwise (because such library does not
     *         exist)
     * @throws DataModelException if there is a system access problem, if
     *             no managed Library has the specified name.
     */
    boolean deleteLibrary(String libraryName)
        throws LibraryException;

    /**
     * Starts managing an existing XML Library in this LibraryManager. Sessions on
     * the Library can then be opened by {@link #openLibrary}.
     * @param libraryName symbolic name of a Library. Must not clash with an
     *        already managed Library.
     * @param libraryDirectory the location of the Library. If value is null and
     *        if the Group directory is defined (see {@link #setGroupDirectory}),
     *        the LibraryManager will look for a Library located at
     *        <em>group-directory/library-name</em>.
     * @exception DataModelException if specified library name already used, if
     *            Library cannot be located.
     * @since 4.0
     */
    void manageLibrary(String libraryName, File libraryDirectory)
        throws LibraryException;

    /**
     * Closes and detaches a XML Library from this LibraryManager. The
     * Library is then no more accessible by {@link #openLibrary}. All sessions
     * if any are automatically closed after a delay.
     * @param libraryName symbolic name of a managed Library. 
     * @param graceTimeMillis a time in milliseconds for which the method will
     *        wait if there are Library sessions with unfinished transactions.
     *        After that time a rollback will be forced on all uncommitted
     *        transactions.
     * @return <code>true</code> if all sessions have been closed without
     *         forced rollback.
     * @exception DataModelException if there is a system access problem.
     * @since 4.0
     */
    boolean unmanageLibrary(String libraryName, int graceTimeMillis)
        throws LibraryException;

    /**
     * Shuts down the manager by unmanaging all the Libraries and releasing
     * resources.
     * @param graceTimeMillis a time in milliseconds for which the method will
     *        wait if there are Library sessions with unfinished transactions.
     *        After that time a rollback will be forced on all uncommitted
     *        transactions.
     * @return <code>true</code> if all sessions have been closed without
     *         forced rollback.
     * @throws DataModelException if there is a system access problem.
     */
    boolean closeAllLibraries(int graceTimeMillis)
        throws DataModelException;

    /**
     * Opens a new session on a Library.
     * <p>
     * Notice that no authentication is performed at this level. The user name is
     * used by the AccessControl to check the permissions of the user.
     * @param libraryName symbolic name of a Library
     * @param accessControl an implementation of {@link AccessControlException}.
     *        this instance can be specific to this session, or specific to the
     *        concerned Library: this is under the control of the implementation.
     * @param user represents an authentified User. If null, then the
     *        AccessControl must be null too (corresponds to the simplified
     *        version without access control).
     * @return a session on the specified Library or <code>null</code> if such a
     *         Library does not exist.
     * @throws DataModelException if there is a system access problem. This
     *         happens normally only when the XML Library is already locked by
     *         another application.
     * @since 4.0 modified to add AccessControl parameter
     */
    Library openLibrary(String libraryName,
                        AccessControl accessControl, User user)
        throws DataModelException;

    /**
     * Opens a new session on a Library.
     * <p>
     * Simplified version used when there is no Access Control.
     * @param libraryName symbolic name of a Library
     * @return a session on the specified Library or <code>null</code> if such a
     *         Library does not exist
     * @throws DataModelException if there is a system access problem. This
     *         happens normally only when the XML Library is already used by
     *         another application.
     * @since 4.0
     */
    Library openLibrary(String libraryName)
        throws DataModelException;

    /**
     * Returns the top-level directory of the Library Group. This directory
     * in general contains one sub-directory for each contained Library.
     * It is non null if this LibraryManager was open with {@link LibraryManagerFactory#openLibraryGroup}.
     * @return a File which is the directory containing the Library Group
     * managed by this object.
     * @since 4.0
     */
    File getGroupDirectory();

    /**
     * Sets the top-level directory of the Library Group. This directory
     * in general contains one sub-directory for each contained Library.
     * @param directory a File which is the root location of the Library Group
     * managed by this object.
     * @since 4.0
     */
    void setGroupDirectory(File directory);
    
    /**
     * Defines the maximum memory size the generated LibraryManager can use.
     * @param size maximum size in bytes of memory allocated to the
     *        LibraryManager.
     * @see #getMemoryLimit
     */
    public abstract void setMemoryLimit(long size);

    /**
     * Defines the maximum memory size the generated LibraryManager can use.
     * @return maximum size in bytes of memory allocated to the LibraryManager.
     * @see #setMemoryLimit
     */
    public abstract long getMemoryLimit();

    /**
     * Gets the document cache.
     */
    DocumentPool getTransientDocumentCache();
    
    /**
     * Sets the maximum memory size for the document cache. The document cache
     * stores transient documents which are parsed in memory but not stored in
     * a XML Library.
     * @param size maximum memory size in bytes. Decreasing this size will flush the
     *        cache accordingly.
     * @return the former maximum memory size in bytes
     */
    long setTransientDocumentCacheSize(long size);

    /**
     * Gets the current maximum memory size for the document cache.
     * @return a size in bytes
     */
    long getTransientDocumentCacheSize();

    /**
     * Sets the resolver used for resolving a module into actual locations. By
     * default, a LibraryManager uses a {@link DefaultModuleResolver}.
     * @param resolver replacement for the current resolver
     */
    void setModuleResolver(ModuleResolver resolver);

    /**
     * Returns the current {@link ModuleResolver}.
     * @return the current Module resolver
     */
    ModuleResolver getModuleResolver();
    
    
    /**
     * Defines a default FullTextFactory for all the XML Libraries opened or
     * created from this Library Manager.
     * <p>
     * A FullTextFactory provides access to- or allows redefining full-text
     * resources such as text tokenizer, stemming, thesaurus and scoring method.
     * @param factory an implementation of FullTextFactory. A new instance is
     *        cloned for each Library. A factory can also be defined for a
     *        specific Library.
     */
    void setFullTextFactory(FullTextFactory factory);
    
    /**
     * Returns the FullTextFactory specified by
     * {@link #setFullTextFactory(FullTextFactory)}.
     * @return the FullTextFactory specified by
     *         {@link #setFullTextFactory(FullTextFactory)} or null if none has
     *         been defined.
     */
    FullTextFactory getFullTextFactory();
    
    /**
     * Returns the logger associated with the LibraryManager. This object can
     * be used by applications to change its configuration.
     * <p>
     * This logger logs starts and shutdowns, and incidents on managed
     * Libraries. It is created with level INFO.
     * <p>
     * @since 4.0 
     */
    Logger getLogger();

    /**
     * Returns the logger associated with a Library. This object can be used by
     * applications to change its configuration.
     * <p>
     * This logger logs internal events of each XML Library.
     * <p>
     * It is created with a daily rolling file output in library/logs/lib.log
     * at level WARNING.
     * @since 4.0 
     */
    Logger getLibraryLogger(String libraryName);

    /**
     * Adds a Logger handler which is used both by the Library Manager and all
     *  the managed Libraries.
     * @param handler
     */
    void addLogHandler(Handler handler);

    /**
     * Adds an observer for access and update operations.
     * @param observer an object implementing this interface.
     */
    void addLibraryObserver(LibraryMemberObserver observer);

    /**
     * Removes an observer of access and update operations.
     * @param observer an object implementing this interface.
     */
    void removeLibraryObserver(LibraryMemberObserver observer);

    /**
     * Returns a list of active LibraryMemberObserver's.
     * @return a non-null (but possibly empty) array of observers
     */
    LibraryMemberObserver[] getLibraryObservers();

    /**
     * Performs a validity check of all managed Libraries.
     * @param log interface reporting errors and messages
     * @param deep perform deep inspection if true
     * @param allowFixing if true and errors are detected, perform fixes if
     * possible. Requires the Libraries to be writable.
     */
    void sanityCheck(Log log, boolean deep, boolean allowFixing);
}
