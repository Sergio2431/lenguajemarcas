/*
 *    Qizx Free_Engine-4.1p1
 *
 *    This code is part of Qizx XQuery engine
 *    Copyright (c) 2004-2010 Axyana Software -- All rights reserved.
 *
 *    For conditions of use, see the accompanying license files.
 */
package com.qizx.api;

import com.qizx.api.util.DefaultModuleResolver;
import com.qizx.util.basic.Check;
import com.qizx.xdm.DocumentPool;
import com.qizx.xquery.ModuleManager;
import com.qizx.xquery.XQuerySessionImpl;

import java.net.URL;

/**
 * Manager of simple XQuery sessions without access to a XML Library.
 * <p>
 * Provides a cache of Modules and a cache of transient documents, shared among
 * the sessions created on this manager. This cache avoids reparsing XML
 * documents if different sessions access it. It can detect a change on
 * documents stored in the file-system and reload the document.
 */
public class XQuerySessionManager
{
    private ModuleManager moduleMan;
    private DocumentPool  documentCache;

    /**
     * Creates a session manager with a default Module Resolver and 
     * a default cache for parsed documents.
     * 
     * @param moduleBaseURI base URI for the default Module Resolver
     */
    public XQuerySessionManager(URL moduleBaseURI)
    {
        this(new DefaultModuleResolver(moduleBaseURI), -1);
    }

    /**
     * Creates a session manager.
     * @param moduleResolver resolver used for modules
     * @param transientDocumentCacheSize size in bytes of the document cache
     */
    public XQuerySessionManager(ModuleResolver moduleResolver,
                                int transientDocumentCacheSize)
    {
        moduleMan = new ModuleManager(moduleResolver);
        documentCache = new DocumentPool();
        if(transientDocumentCacheSize >= 0)
            documentCache.setCacheSize(transientDocumentCacheSize);
    }

    /**
     * Creates a new XQuery session.
     * @return a new XQuery session using the resources of this session manager
     */
    public XQuerySession createSession()
    {
        return new XQuerySessionImpl(this);
    }

    /**
     * For internal use.
     */
    public ModuleManager getModuleManager()
    {
        return moduleMan;
    }

    /**
     * Sets the maximum memory size for the document cache. The document cache
     * stores transient documents which are parsed in memory.
     * @param size maximum memory size in bytes. Decreasing this size will
     *        flush the cache accordingly.
     * @return the former maximum memory size in bytes
     */
    public long setTransientDocumentCacheSize(long size)
    {
        long oldSize = documentCache.getCacheSize();
        documentCache.setCacheSize(size);
        return oldSize;
    }

    /**
     * Gets the current maximum memory size for the document cache.
     * @return a size in bytes
     */
    public long getTransientDocumentCacheSize()
    {
        return documentCache.getCacheSize();
    }

    /**
     * For internal use.
     */
    public DocumentPool getDocumentCache()
    {
        return documentCache;
    }

    /**
     * For internal use.
     */
    public void setDocumentCache(DocumentPool documentCache)
    {
        this.documentCache = documentCache;
    }

    /**
     * Defines a resolver of XQuery modules.
     * @param resolver a module resolver
     */
    public void setModuleResolver(ModuleResolver resolver)
    {
        Check.nonNull(resolver, "resolver");
        moduleMan.setResolver(resolver);
    }
    
    /**
     * Returns the current Resolver of XQuery modules.
     * @return the current module resolver
     */
    public ModuleResolver getModuleResolver()
    {
        return moduleMan.getResolver();
    }
}
